function arraySample(){
	var produce [
	  'egg'
	  'lettuce'
	  'apple'
	  'tomato'
	  'grape'
	  'pineapaple'
	  'mango'
	  'corn'
]

    arrayDisplay.innerHTML =
	produce
}

console.log(produce);

document.getElementById("display").innerHTML = produce;


	 
